package ebay;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class ebay1 {
	
	WebDriver driver;
	public void launchBrowser() {
		System.setProperty("webdriver.chrome.driver","C://selenium//chromedriver//chromedriver.exe");
		driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().deleteAllCookies();
		driver.get("http://localhost:4200");
	}
	
	
	//Test case 1
	public void FirstDoctorRegistration() throws InterruptedException{
		driver.findElement(By.id("gh-ac")).click();
		Thread.sleep(2000);
		driver.findElement(By.id("signup")).click();
		Thread.sleep(2000);
		driver.findElement(By.id("name")).sendKeys("Vivek1");
		Thread.sleep(2000);
		driver.findElement(By.id("username")).sendKeys("vpm1@gmail.com");
		Thread.sleep(2000);
		driver.findElement(By.id("email")).sendKeys("vpm1@gmail.com");
		Thread.sleep(2000);
		driver.findElement(By.id("password")).sendKeys("vpm1@1234");
		Thread.sleep(2000);
		driver.findElement(By.id("button1")).click();
	}
	
	//Test case 2
	public void Successlogin() throws InterruptedException {
		Thread.sleep(1000);
		driver.findElement(By.id("gh-ac")).click();
		Thread.sleep(2000);
		driver.findElement(By.id("email")).sendKeys("vpm@gmail.com");
		Thread.sleep(2000);
		driver.findElement(By.id("password")).sendKeys("vpm@1234");
		Thread.sleep(2000);
		driver.findElement(By.id("button")).click();
		Thread.sleep(2000);
		driver.findElement(By.id("logout")).click();
	}
	
	//Test case 3
	public void PatientFailed() throws InterruptedException{
		driver.findElement(By.id("gh-ac")).click();
		Thread.sleep(2000);
		driver.findElement(By.id("email")).sendKeys("vivpm@gmail.com");
		Thread.sleep(2000);
		driver.findElement(By.id("password")).sendKeys("vpm1234");
		Thread.sleep(2000);
		driver.findElement(By.id("button")).click();
		Thread.sleep(2000);
		driver.switchTo().alert().accept();
		driver.navigate().refresh();
	}
	
	//Test case 4
	public void Appointment() throws InterruptedException {
		driver.findElement(By.id("gh-mc")).click();
		driver.findElement(By.id("Appointment")).click();
		Thread.sleep(1000);
		driver.findElement(By.id("fname")).sendKeys("Prateek PM");
		Thread.sleep(2000);
		driver.findElement(By.id("date")).sendKeys("03-12-2022");
		Thread.sleep(2000);
		driver.findElement(By.id("Time")).sendKeys("11:00-11:30 AM");
		Thread.sleep(2000);
		driver.findElement(By.id("phone")).sendKeys("4379834723");
		Thread.sleep(2000);
		driver.findElement(By.id("Select")).sendKeys("Cardiology");
		Thread.sleep(2000);
		driver.findElement(By.id("Select1")).sendKeys("offline");
		Thread.sleep(2000);
		driver.findElement(By.id("button")).click();
		driver.switchTo().alert().accept();
	}
	
	//Test case 5
		public void AddPatient() throws InterruptedException{
			driver.findElement(By.id("gh-ac")).click();
			driver.findElement(By.id("email")).sendKeys("vpm@gmail.com");
			Thread.sleep(2000);
			driver.findElement(By.id("password")).sendKeys("vpm@1234");
			driver.findElement(By.id("button")).click();
			Thread.sleep(2000);
			driver.findElement(By.id("b1")).click();
			Thread.sleep(2000);	
			driver.findElement(By.id("name")).sendKeys("XYZ1");
			Thread.sleep(2000);	
			driver.findElement(By.id("problem")).sendKeys("Headache1");
			Thread.sleep(2000);	
			driver.findElement(By.id("solution")).sendKeys("Paracetmol1");
			Thread.sleep(2000);	
			driver.findElement(By.id("date")).sendKeys("05-02-2023");
			Thread.sleep(2000);	
			driver.findElement(By.id("gen")).sendKeys("Male");
			Thread.sleep(2000);	
			driver.findElement(By.id("radio-4")).sendKeys("Video Call");
			Thread.sleep(2000);	
			driver.findElement(By.id("b3")).click();
			driver.switchTo().alert().accept();
		}
		
		//Test case 6
		public void UpdatePatient() throws InterruptedException {
			driver.findElement(By.id("gh-ac")).click();
			Thread.sleep(2000); 
			driver.findElement(By.id("email")).sendKeys("vpm@gmail.com");
			Thread.sleep(2000);
			driver.findElement(By.id("password")).sendKeys("vpm@1234");
			Thread.sleep(2000);
			driver.findElement(By.id("button")).click();
			Thread.sleep(2000);
			driver.findElement(By.id("update")).click();
			Thread.sleep(2000);
			WebElement query = driver.findElement(By.id("name"));
			query.clear();
			query.sendKeys("XYZ");
			Thread.sleep(2000);
			driver.findElement(By.id("b3")).click();
			Thread.sleep(2000);
			driver.switchTo().alert().accept();
			driver.findElement(By.id("display")).click();
			Thread.sleep(2000);
		}
		
		//Test Case 7
		public void DeletePatient() throws InterruptedException {
			driver.findElement(By.id("gh-ac")).click();
			Thread.sleep(2000);
			driver.findElement(By.id("email")).sendKeys("vpm@gmail.com");
			Thread.sleep(2000);
			driver.findElement(By.id("password")).sendKeys("vpm@1234");
			Thread.sleep(2000);
			driver.findElement(By.id("button")).click();
			Thread.sleep(2000);	
			driver.findElement(By.id("delete")).click();		
			Thread.sleep(2000);
			driver.findElement(By.id("logout")).click();
		}
		
//		//Test Case 8
		public void Navigation() throws InterruptedException{
			driver.findElement(By.id("gh-bc")).click();
			JavascriptExecutor js = (JavascriptExecutor) driver;
			Thread.sleep(4000);
			js.executeScript("window.scrollBy(0,250)", "");
			Thread.sleep(4000);
			js.executeScript("window.scrollBy(250,500)", "");
			Thread.sleep(4000);
			js.executeScript("window.scrollBy(500,0)", "");
			Thread.sleep(4000);
			driver.findElement(By.id("gh-hc")).click();
			JavascriptExecutor js1 = (JavascriptExecutor) driver;
			Thread.sleep(4000);
			js1.executeScript("window.scrollBy(0,250)", "");
			Thread.sleep(4000);
			js1.executeScript("window.scrollBy(250,500)", "");
			Thread.sleep(4000);
			js1.executeScript("window.scrollBy(500,750)", "");
			Thread.sleep(4000);
			js1.executeScript("window.scrollBy(750,0)", "");
			Thread.sleep(4000);
			driver.findElement(By.id("gh-md")).click();
			JavascriptExecutor js2 = (JavascriptExecutor) driver;
			Thread.sleep(4000);
			js2.executeScript("window.scrollBy(0,250)", "");
			Thread.sleep(4000);
			js2.executeScript("window.scrollBy(250,500)", "");
			Thread.sleep(4000);
			js2.executeScript("window.scrollBy(500,750)", "");
			Thread.sleep(4000);
			js2.executeScript("window.scrollBy(750,0)", "");
			Thread.sleep(4000);
			driver.findElement(By.id("gh-bc")).click();
		}
		
	
	public void closeBrowser() {
		driver.quit();
	}
	
	public static void main(String[] args) throws InterruptedException {
		ebay1 ebay = new ebay1();
		ebay.launchBrowser();
//		ebay.Navigation();
//		ebay.FirstDoctorRegistration();
//		ebay.Successlogin();
		ebay.PatientFailed();
//		ebay.Appointment();
//		ebay.AddPatient();
//		ebay.UpdatePatient();
//		ebay.DeletePatient();
//		ebay.closeBrowser();
		
	}
	

}
